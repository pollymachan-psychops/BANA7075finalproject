import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, classification_report, top_k_accuracy_score

BASE = Path('/mnt/data')
CLINICAL_PATH = BASE / 'sparksync_clinical_data_with_outcomes (1).csv'
PROGRAMS_PATH = BASE / 'programs_ml_dataset clean.xlsx'


def load_data():
    clinical = pd.read_csv(CLINICAL_PATH)
    programs = pd.read_excel(PROGRAMS_PATH)
    return clinical, programs


def prepare_features(df: pd.DataFrame, include_last_elected_program: bool = False):
    target = 'actual_disposition'
    drop_cols = ['mrn', target]
    X = df.drop(columns=drop_cols).copy()

    if not include_last_elected_program and 'last_elected_program' in X.columns:
        X = X.drop(columns=['last_elected_program'])

    # Drop columns that are completely empty
    empty_cols = [c for c in X.columns if X[c].isna().all()]
    if empty_cols:
        X = X.drop(columns=empty_cols)

    # Force diagnosis columns to categorical/object if present
    for c in X.columns:
        if c.startswith('diagnosis_'):
            X[c] = X[c].astype('object')

    y = df[target].copy()
    cat_cols = X.select_dtypes(include=['object', 'bool']).columns.tolist()
    num_cols = [c for c in X.columns if c not in cat_cols]
    return X, y, num_cols, cat_cols


def build_pipeline(num_cols, cat_cols):
    preprocessor = ColumnTransformer([
        ('num', Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', StandardScaler())
        ]), num_cols),
        ('cat', Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('onehot', OneHotEncoder(handle_unknown='ignore'))
        ]), cat_cols)
    ])

    model = LogisticRegression(max_iter=2000, class_weight='balanced')

    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('model', model)
    ])
    return pipeline


def extract_top_features(fitted_pipeline, top_n=8):
    pre = fitted_pipeline.named_steps['preprocessor']
    model = fitted_pipeline.named_steps['model']

    num_cols = pre.transformers_[0][2]
    cat_cols = pre.transformers_[1][2]
    onehot = pre.named_transformers_['cat'].named_steps['onehot']

    feature_names = list(num_cols) + list(onehot.get_feature_names_out(cat_cols))
    classes = model.classes_
    coefs = model.coef_

    rows = []
    for i, cls in enumerate(classes):
        coef_row = coefs[i]
        top_idx = np.argsort(np.abs(coef_row))[-top_n:][::-1]
        for rank, j in enumerate(top_idx, start=1):
            rows.append({
                'facility': cls,
                'rank': rank,
                'feature': feature_names[j],
                'coefficient': float(coef_row[j])
            })
    return pd.DataFrame(rows)


def main():
    clinical, programs = load_data()

    observed_programs = set(clinical['actual_disposition'].dropna().unique())
    all_programs = set(programs['program_name'].dropna().unique())
    unseen_programs = sorted(all_programs - observed_programs)

    X, y, num_cols, cat_cols = prepare_features(clinical, include_last_elected_program=False)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    pipeline = build_pipeline(num_cols, cat_cols)
    pipeline.fit(X_train, y_train)

    pred = pipeline.predict(X_test)
    proba = pipeline.predict_proba(X_test)
    classes = pipeline.named_steps['model'].classes_

    metrics = {
        'accuracy': accuracy_score(y_test, pred),
        'macro_f1': f1_score(y_test, pred, average='macro', zero_division=0),
        'weighted_f1': f1_score(y_test, pred, average='weighted', zero_division=0),
        'top3_accuracy': top_k_accuracy_score(y_test, proba, k=3, labels=classes)
    }

    report = classification_report(y_test, pred, output_dict=True, zero_division=0)
    class_metrics = []
    for cls in classes:
        d = report.get(cls, {})
        class_metrics.append({
            'facility': cls,
            'precision': d.get('precision', np.nan),
            'recall': d.get('recall', np.nan),
            'f1_score': d.get('f1-score', np.nan),
            'support': d.get('support', np.nan)
        })
    class_metrics_df = pd.DataFrame(class_metrics).sort_values('support', ascending=False)

    top3_idx = np.argsort(-proba, axis=1)[:, :3]
    prediction_rows = []
    for row_num, original_idx in enumerate(X_test.index):
        inds = top3_idx[row_num]
        prediction_rows.append({
            'row_id': int(original_idx),
            'actual': y_test.loc[original_idx],
            'predicted': pred[row_num],
            'top1': classes[inds[0]],
            'top1_prob': float(proba[row_num, inds[0]]),
            'top2': classes[inds[1]],
            'top2_prob': float(proba[row_num, inds[1]]),
            'top3': classes[inds[2]],
            'top3_prob': float(proba[row_num, inds[2]])
        })
    prediction_df = pd.DataFrame(prediction_rows)

    feature_df = extract_top_features(pipeline, top_n=8)

    pd.DataFrame([metrics]).to_csv(BASE / 'facility_model_metrics.csv', index=False)
    class_metrics_df.to_csv(BASE / 'facility_model_class_metrics.csv', index=False)
    prediction_df.to_csv(BASE / 'facility_model_predictions.csv', index=False)
    feature_df.to_csv(BASE / 'facility_model_top_features.csv', index=False)

    summary_path = BASE / 'facility_model_summary.txt'
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write('Facility Prediction Model Summary\n')
        f.write('================================\n\n')
        f.write('Clinical rows: {}\n'.format(len(clinical)))
        f.write('Observed outcome facilities: {}\n'.format(len(observed_programs)))
        f.write('Program catalog facilities: {}\n'.format(len(all_programs)))
        f.write('Facilities not learnable from this outcome data: {}\n\n'.format(', '.join(unseen_programs) if unseen_programs else 'None'))
        for k, v in metrics.items():
            f.write(f'{k}: {v:.4f}\n')

    print('Done.')
    print('Saved:')
    print(BASE / 'facility_model_metrics.csv')
    print(BASE / 'facility_model_class_metrics.csv')
    print(BASE / 'facility_model_predictions.csv')
    print(BASE / 'facility_model_top_features.csv')
    print(BASE / 'facility_model_summary.txt')


if __name__ == '__main__':
    main()
