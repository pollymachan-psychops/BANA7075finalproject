# Model Selection Rationale

## Summary
Two different model formulations were created because they solve related but slightly different problems:

1. **`build_facility_prediction_model.py`**
   - A direct **multiclass classification** baseline.
   - Predicts the single observed facility label from patient features only.

2. **`build_facility_ranker.py`**
   - A **binary ranking model** over patient-program pairs.
   - Scores every facility for each patient using both patient and program attributes.

The ranking model is the preferred production candidate.

## Why start with logistic regression
Logistic regression was selected first in both scripts for practical and technical reasons:
- the data is tabular and heavily mixed between numeric and categorical fields,
- the preprocessing pipeline yields sparse one-hot encoded matrices that logistic regression handles well,
- it is fast, stable, reproducible, and easy to serialize,
- it produces meaningful coefficients and well-behaved probabilities for baseline scoring,
- class weighting helps mitigate facility imbalance,
- it provides a transparent reference point before trying more complex algorithms.

## Why the multiclass model was built
The multiclass classifier was useful as a benchmark because it answers a straightforward question:
> Can the clinical data alone predict the observed destination facility?

This baseline helps assess:
- raw signal in the patient features,
- class imbalance severity,
- whether the target is learnable at all,
- top-k shortlist usefulness,
- early leakage risks such as `last_elected_program`.

However, it is limited because it does **not** incorporate program-level attributes during prediction.

## Why the ranking model is preferred
The ranking model better matches the actual use case:
> Given a new patient, which facilities should be recommended?

This formulation is superior because it:
- evaluates every available facility,
- incorporates program metadata directly,
- supports top-k recommendation output,
- works better when a shortlist is more useful than a single forced prediction,
- can score facilities that are rare or unseen in historical outcome labels.

In other words, the multiclass model is a useful benchmark, but the ranking model is more operationally realistic.

## Why not jump directly to tree ensembles
More complex models such as Random Forest, XGBoost, LightGBM, or CatBoost may improve performance, but they were not chosen as the first implementation because:
- the initial objective was to build a clear, reproducible baseline,
- linear models are easier to audit for leakage and spurious dependence,
- sparse one-hot encoded data often gives strong baseline results with logistic regression,
- explanation and debugging are simpler early in development.

Once the data pipeline is validated, ensemble methods are the logical next comparison.

## Recommended model hierarchy
### Baseline / audit stage
Use:
- logistic regression multiclass classifier
- logistic regression pairwise ranker

### Next comparison stage
Evaluate:
- LightGBM binary ranker
- XGBoost multiclass classifier
- CatBoost for mixed categorical handling

### Production hardening stage
Add:
- probability calibration,
- repeated cross-validation,
- subgroup performance auditing,
- drift monitoring,
- explanation layer,
- business-rule constraints such as geography, insurance, availability, and wait time.

## Final recommendation
- Use **`build_facility_prediction_model.py`** as the interpretable benchmark and sanity check.
- Use **`build_facility_ranker.py`** as the main deployment candidate for recommending facilities to new patients.
