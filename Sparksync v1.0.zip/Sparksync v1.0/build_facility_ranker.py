#!/usr/bin/env python3
"""
Train and use a patient-to-facility ranking model for treatment facility selection.

This script uses:
  1) programs_ml_dataset clean.xlsx  -> facility/program attributes
  2) sparksync_clinical_data_with_outcomes (1).csv -> patient clinical data + observed facility outcome

Outputs:
  - a serialized model bundle (.joblib)
  - evaluation metrics and optional holdout predictions
  - ranked facility recommendations for new patients

Examples
--------
Train:
python build_facility_ranker.py train \
  --clinical "sparksync_clinical_data_with_outcomes (1).csv" \
  --programs "programs_ml_dataset clean.xlsx" \
  --model-out facility_ranker.joblib \
  --metrics-out facility_ranker_metrics.json \
  --predictions-out holdout_rankings.csv

Predict on new patients:
python build_facility_ranker.py predict \
  --model-in facility_ranker.joblib \
  --new-patients new_patients.csv \
  --out scored_recommendations.csv \
  --top-k 5
"""
from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

RANDOM_STATE = 42
TARGET_COL = "actual_disposition"
PROGRAM_NAME_COL = "program_name"
PATIENT_ID_COL = "_patient_row_id"


@dataclass
class ModelBundle:
    pipeline: Pipeline
    programs_df: pd.DataFrame
    feature_columns: List[str]
    numeric_columns: List[str]
    categorical_columns: List[str]
    patient_columns: List[str]
    metadata: Dict


def read_table(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    raise ValueError(f"Unsupported file type for {path}. Use CSV or Excel.")


def normalize_text(value):
    if pd.isna(value):
        return np.nan
    value = str(value).strip()
    value = re.sub(r"\s+", " ", value)
    return value if value else np.nan


def clean_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df


def clean_inputs(clinical_df: pd.DataFrame, programs_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    clinical_df = clean_columns(clinical_df)
    programs_df = clean_columns(programs_df)

    if TARGET_COL in clinical_df.columns:
        clinical_df[TARGET_COL] = clinical_df[TARGET_COL].map(normalize_text)
    if PROGRAM_NAME_COL in programs_df.columns:
        programs_df[PROGRAM_NAME_COL] = programs_df[PROGRAM_NAME_COL].map(normalize_text)

    # Normalize text/object columns for consistency.
    for df in (clinical_df, programs_df):
        obj_cols = df.select_dtypes(include=["object"]).columns
        for col in obj_cols:
            df[col] = df[col].map(normalize_text)

    return clinical_df, programs_df


def ensure_patient_id(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if PATIENT_ID_COL not in df.columns:
        df[PATIENT_ID_COL] = np.arange(len(df))
    return df


def add_pair_features(pairs: pd.DataFrame) -> pd.DataFrame:
    pairs = pairs.copy()

    def contains_match(left, right):
        if pd.isna(left) or pd.isna(right):
            return 0
        return int(str(left).lower() in str(right).lower())

    pairs["specialty_match"] = (
        pairs.get("treatment_specialty_patient", pd.Series(index=pairs.index, dtype=object)).fillna("").str.lower()
        == pairs.get("treatment_specialty_program", pd.Series(index=pairs.index, dtype=object)).fillna("").str.lower()
    ).astype(int)

    if "level_of_care" in pairs.columns and "levels_of_care" in pairs.columns:
        pairs["level_of_care_match"] = [contains_match(a, b) for a, b in zip(pairs["level_of_care"], pairs["levels_of_care"])]
    else:
        pairs["level_of_care_match"] = 0

    if "program_duration_preference" in pairs.columns and "length_of_stay" in pairs.columns:
        pairs["duration_match"] = [contains_match(a, b) for a, b in zip(pairs["program_duration_preference"], pairs["length_of_stay"])]
    else:
        pairs["duration_match"] = 0

    if "last_elected_program" in pairs.columns and PROGRAM_NAME_COL in pairs.columns:
        pairs["program_seen_before"] = (
            pairs["last_elected_program"].fillna("").str.lower()
            == pairs[PROGRAM_NAME_COL].fillna("").str.lower()
        ).astype(int)
    else:
        pairs["program_seen_before"] = 0

    return pairs


def build_pair_dataset(clinical_df: pd.DataFrame, programs_df: pd.DataFrame, training: bool = True) -> pd.DataFrame:
    clinical_df = ensure_patient_id(clinical_df)
    left = clinical_df.assign(_tmp_key=1)
    right = programs_df.assign(_tmp_key=1)
    pairs = left.merge(right, on="_tmp_key", suffixes=("_patient", "_program")).drop(columns=["_tmp_key"])
    pairs = add_pair_features(pairs)
    if training:
        pairs["label"] = (pairs[TARGET_COL] == pairs[PROGRAM_NAME_COL]).astype(int)
    return pairs


def build_feature_lists(pairs: pd.DataFrame) -> Tuple[List[str], List[str], List[str], List[str]]:
    excluded = {"label", TARGET_COL, PROGRAM_NAME_COL, PATIENT_ID_COL, "mrn"}
    candidate_columns = [c for c in pairs.columns if c not in excluded]
    feature_columns = []
    for col in candidate_columns:
        if pd.api.types.is_numeric_dtype(pairs[col]):
            if pairs[col].notna().any():
                feature_columns.append(col)
        else:
            feature_columns.append(col)
    numeric_columns = [c for c in feature_columns if pd.api.types.is_numeric_dtype(pairs[c])]
    categorical_columns = [c for c in feature_columns if c not in numeric_columns]
    patient_columns = [c for c in pairs.columns if c.endswith("_patient") or c in {PATIENT_ID_COL}]
    return feature_columns, numeric_columns, categorical_columns, patient_columns


def make_pipeline(numeric_columns: List[str], categorical_columns: List[str]) -> Pipeline:
    preprocessor = ColumnTransformer(
        transformers=[
            (
                "num",
                Pipeline(
                    steps=[
                        ("imputer", SimpleImputer(strategy="median")),
                        ("scaler", StandardScaler(with_mean=False)),
                    ]
                ),
                numeric_columns,
            ),
            (
                "cat",
                Pipeline(
                    steps=[
                        ("imputer", SimpleImputer(strategy="most_frequent")),
                        (
                            "onehot",
                            OneHotEncoder(handle_unknown="ignore", min_frequency=10),
                        ),
                    ]
                ),
                categorical_columns,
            ),
        ]
    )

    classifier = LogisticRegression(
        max_iter=1000,
        class_weight="balanced",
        solver="liblinear",
        random_state=RANDOM_STATE,
    )

    return Pipeline(steps=[("preprocessor", preprocessor), ("classifier", classifier)])


def compute_topk_metrics(scored_pairs: pd.DataFrame, ks: List[int] = [1, 3, 5]) -> Dict[str, float]:
    metrics = {}
    ranked = scored_pairs.sort_values([PATIENT_ID_COL, "score"], ascending=[True, False])
    for k in ks:
        hit = ranked.groupby(PATIENT_ID_COL).head(k).groupby(PATIENT_ID_COL)["label"].max()
        metrics[f"top_{k}_accuracy"] = float(hit.mean())
    return metrics


def evaluate_holdout(scored_pairs: pd.DataFrame) -> Dict:
    ranked = scored_pairs.sort_values([PATIENT_ID_COL, "score"], ascending=[True, False])
    top1 = ranked.groupby(PATIENT_ID_COL).head(1)[[PATIENT_ID_COL, PROGRAM_NAME_COL]].rename(columns={PROGRAM_NAME_COL: "predicted_program"})
    actual = scored_pairs.loc[scored_pairs["label"] == 1, [PATIENT_ID_COL, PROGRAM_NAME_COL]].rename(columns={PROGRAM_NAME_COL: "actual_program"})
    comparison = actual.merge(top1, on=PATIENT_ID_COL, how="inner")

    metrics = compute_topk_metrics(scored_pairs)
    metrics["top_1_exact_match"] = float((comparison["actual_program"] == comparison["predicted_program"]).mean())
    metrics["n_holdout_patients"] = int(comparison.shape[0])

    report = classification_report(
        comparison["actual_program"],
        comparison["predicted_program"],
        output_dict=True,
        zero_division=0,
    )
    return {"metrics": metrics, "classification_report": report}


def train_model(clinical_path: str, programs_path: str) -> Tuple[ModelBundle, Dict, pd.DataFrame]:
    clinical_df = read_table(clinical_path)
    programs_df = read_table(programs_path)
    clinical_df, programs_df = clean_inputs(clinical_df, programs_df)

    missing_outcomes = clinical_df[TARGET_COL].isna().sum() if TARGET_COL in clinical_df.columns else len(clinical_df)
    if missing_outcomes:
        clinical_df = clinical_df.loc[clinical_df[TARGET_COL].notna()].copy()

    pair_df = build_pair_dataset(clinical_df, programs_df, training=True)
    feature_columns, numeric_columns, categorical_columns, patient_columns = build_feature_lists(pair_df)

    splitter = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=RANDOM_STATE)
    train_idx, test_idx = next(splitter.split(pair_df, groups=pair_df[PATIENT_ID_COL]))

    train_pairs = pair_df.iloc[train_idx].copy()
    test_pairs = pair_df.iloc[test_idx].copy()

    pipeline = make_pipeline(numeric_columns, categorical_columns)
    pipeline.fit(train_pairs[feature_columns], train_pairs["label"])

    test_pairs["score"] = pipeline.predict_proba(test_pairs[feature_columns])[:, 1]
    evaluation = evaluate_holdout(test_pairs)

    observed_programs = sorted(clinical_df[TARGET_COL].dropna().unique().tolist())
    all_programs = sorted(programs_df[PROGRAM_NAME_COL].dropna().unique().tolist())
    unseen_programs = sorted(set(all_programs) - set(observed_programs))

    metadata = {
        "random_state": RANDOM_STATE,
        "n_clinical_rows": int(clinical_df.shape[0]),
        "n_program_rows": int(programs_df.shape[0]),
        "n_pair_rows": int(pair_df.shape[0]),
        "observed_programs": observed_programs,
        "unseen_programs_in_training": unseen_programs,
        "target_column": TARGET_COL,
        "program_name_column": PROGRAM_NAME_COL,
    }

    bundle = ModelBundle(
        pipeline=pipeline,
        programs_df=programs_df,
        feature_columns=feature_columns,
        numeric_columns=numeric_columns,
        categorical_columns=categorical_columns,
        patient_columns=[c for c in clinical_df.columns if c != TARGET_COL],
        metadata=metadata,
    )
    return bundle, evaluation, test_pairs


def save_bundle(bundle: ModelBundle, path: str | Path) -> None:
    payload = {
        "pipeline": bundle.pipeline,
        "programs_df": bundle.programs_df,
        "feature_columns": bundle.feature_columns,
        "numeric_columns": bundle.numeric_columns,
        "categorical_columns": bundle.categorical_columns,
        "patient_columns": bundle.patient_columns,
        "metadata": bundle.metadata,
    }
    joblib.dump(payload, path)


def load_bundle(path: str | Path) -> ModelBundle:
    payload = joblib.load(path)
    return ModelBundle(**payload)


def score_new_patients(bundle: ModelBundle, new_patients_path: str, top_k: int = 5) -> pd.DataFrame:
    new_patients = read_table(new_patients_path)
    new_patients = clean_columns(new_patients)

    # Allow optional target column to be present; drop it for scoring.
    if TARGET_COL in new_patients.columns:
        new_patients = new_patients.drop(columns=[TARGET_COL])

    # Add any missing patient columns expected from training.
    expected_cols = [c for c in bundle.patient_columns if c != TARGET_COL]
    for col in expected_cols:
        if col not in new_patients.columns:
            new_patients[col] = np.nan

    # Keep only the expected patient columns plus any identifier columns the user supplied.
    keep_cols = list(dict.fromkeys(expected_cols + [c for c in new_patients.columns if c not in expected_cols]))
    new_patients = new_patients[keep_cols].copy()
    new_patients = ensure_patient_id(new_patients)

    pair_df = build_pair_dataset(new_patients, bundle.programs_df, training=False)

    # Ensure all trained feature columns exist.
    for col in bundle.feature_columns:
        if col not in pair_df.columns:
            pair_df[col] = np.nan

    pair_df["score"] = bundle.pipeline.predict_proba(pair_df[bundle.feature_columns])[:, 1]
    ranked = pair_df.sort_values([PATIENT_ID_COL, "score"], ascending=[True, False]).copy()
    ranked["recommendation_rank"] = ranked.groupby(PATIENT_ID_COL).cumcount() + 1
    ranked = ranked.loc[ranked["recommendation_rank"] <= top_k].copy()

    id_cols = [c for c in ["mrn", PATIENT_ID_COL, "age", "gender", "primary_diagnosis", "level_of_care", "treatment_specialty_patient"] if c in ranked.columns]
    output_cols = id_cols + [PROGRAM_NAME_COL, "score", "recommendation_rank"]

    # Add a few useful program descriptors if present.
    for col in ["location", "levels_of_care", "treatment_specialty_program", "cost_tier", "acuity_level"]:
        if col in ranked.columns:
            output_cols.append(col)

    return ranked[output_cols].rename(columns={"treatment_specialty_patient": "patient_treatment_specialty", "treatment_specialty_program": "program_treatment_specialty"})


def write_template(clinical_path: str, out_path: str | Path, n_rows: int = 3) -> None:
    clinical_df = read_table(clinical_path)
    clinical_df = clean_columns(clinical_df)
    cols = [c for c in clinical_df.columns if c != TARGET_COL]
    template = pd.DataFrame([{c: np.nan for c in cols} for _ in range(n_rows)])
    if "mrn" in template.columns:
        template["mrn"] = [f"NEW_{i+1:03d}" for i in range(n_rows)]
    out_path = Path(out_path)
    if out_path.suffix.lower() == ".csv":
        template.to_csv(out_path, index=False)
    else:
        template.to_excel(out_path, index=False)


def main():
    parser = argparse.ArgumentParser(description="Train and score a patient-to-facility ranking model.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    train_p = subparsers.add_parser("train", help="Train the ranking model and save it.")
    train_p.add_argument("--clinical", required=True, help="Clinical CSV/XLSX with actual_disposition.")
    train_p.add_argument("--programs", required=True, help="Program catalog CSV/XLSX.")
    train_p.add_argument("--model-out", required=True, help="Path to save the trained joblib bundle.")
    train_p.add_argument("--metrics-out", help="Optional JSON file for evaluation metrics.")
    train_p.add_argument("--predictions-out", help="Optional CSV/XLSX for holdout rankings.")
    train_p.add_argument("--template-out", help="Optional CSV/XLSX template for scoring new patients.")

    predict_p = subparsers.add_parser("predict", help="Score new patients using a saved model.")
    predict_p.add_argument("--model-in", required=True, help="Saved joblib model bundle.")
    predict_p.add_argument("--new-patients", required=True, help="New patient CSV/XLSX.")
    predict_p.add_argument("--out", required=True, help="Output CSV/XLSX for ranked facility recommendations.")
    predict_p.add_argument("--top-k", type=int, default=5, help="How many facilities to return per patient.")

    template_p = subparsers.add_parser("template", help="Write a blank new-patient scoring template.")
    template_p.add_argument("--clinical", required=True, help="Clinical CSV/XLSX used only for schema reference.")
    template_p.add_argument("--out", required=True, help="Output CSV/XLSX template path.")
    template_p.add_argument("--rows", type=int, default=3, help="Number of blank example rows.")

    args = parser.parse_args()

    if args.command == "train":
        bundle, evaluation, holdout_pairs = train_model(args.clinical, args.programs)
        save_bundle(bundle, args.model_out)

        if args.metrics_out:
            with open(args.metrics_out, "w", encoding="utf-8") as f:
                json.dump({**bundle.metadata, **evaluation}, f, indent=2)

        if args.predictions_out:
            scored = holdout_pairs.sort_values([PATIENT_ID_COL, "score"], ascending=[True, False]).copy()
            scored["recommendation_rank"] = scored.groupby(PATIENT_ID_COL).cumcount() + 1
            out_path = Path(args.predictions_out)
            if out_path.suffix.lower() == ".csv":
                scored.to_csv(out_path, index=False)
            else:
                scored.to_excel(out_path, index=False)

        if args.template_out:
            write_template(args.clinical, args.template_out)

        print(json.dumps({**bundle.metadata, **evaluation["metrics"]}, indent=2))

    elif args.command == "predict":
        bundle = load_bundle(args.model_in)
        recommendations = score_new_patients(bundle, args.new_patients, top_k=args.top_k)
        out_path = Path(args.out)
        if out_path.suffix.lower() == ".csv":
            recommendations.to_csv(out_path, index=False)
        else:
            recommendations.to_excel(out_path, index=False)
        print(f"Wrote ranked recommendations to {out_path}")

    elif args.command == "template":
        write_template(args.clinical, args.out, n_rows=args.rows)
        print(f"Wrote template to {args.out}")


if __name__ == "__main__":
    main()
