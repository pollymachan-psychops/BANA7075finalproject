# README — `build_facility_ranker.py`

## Purpose
This script trains a **patient-to-facility ranking model** that scores every program in the facility catalog for each patient and returns the top recommendations.

Unlike the multiclass baseline, this script combines:
- patient-level clinical features, and
- facility/program-level attributes

This makes it the stronger deployment-oriented approach for scoring new patient referrals.

## Data inputs
The script expects two source files:
- `sparksync_clinical_data_with_outcomes (1).csv` — patient data with observed treatment outcome in `actual_disposition`
- `programs_ml_dataset clean.xlsx` — facility/program catalog with program attributes

Supported formats are CSV and Excel.

## Learning problem formulation
### Training label
For each patient, the script creates one row per facility by performing a patient × program cross join.

Each patient-program pair receives:
- `label = 1` if `actual_disposition == program_name`
- `label = 0` otherwise

This converts the problem into a **binary relevance ranking problem**.

### Unit of prediction
- **Training unit:** one patient-program pair
- **Inference unit:** one patient-program pair
- **Final output:** ranked list of facilities per patient

## Why this formulation was selected
A ranking formulation was selected because it is better aligned with real-world referral recommendation workflows.

Advantages over direct multiclass classification:
1. It scores **all facilities** for each patient.
2. It uses **program metadata** directly during training and inference.
3. It returns a **top-k recommendation list**, which is operationally more useful than a single forced class.
4. It can still assign scores to facilities with sparse or no positive history, based on program attributes and pairwise matching features.
5. It supports future expansion to new facilities without fully redesigning the pipeline.

## High-level pipeline
1. Load clinical and program data.
2. Normalize column names and text values.
3. Remove patient rows with missing `actual_disposition` during training.
4. Create a unique patient ID if one is not present.
5. Build a patient × program pair dataset using a cross join.
6. Add pairwise match features that compare patient needs to program attributes.
7. Split the data into train and test sets using **group-aware splitting by patient**.
8. Train a binary classifier to estimate the probability that a patient-program pair is the observed match.
9. Score every holdout patient against every facility.
10. Sort scores within each patient and compute top-k ranking metrics.
11. Save the trained model bundle for later scoring of new patient rows.

## Pairwise engineered features
The script creates several features intended to bridge patient needs and facility characteristics:
- `specialty_match`
- `level_of_care_match`
- `duration_match`
- `program_seen_before`

These features encode whether a program appears aligned with patient preferences or prior history.

## Model architecture
### Preprocessing
- **Numeric:** `SimpleImputer(strategy="median")` → `StandardScaler(with_mean=False)`
- **Categorical:** `SimpleImputer(strategy="most_frequent")` → `OneHotEncoder(handle_unknown="ignore", min_frequency=10)`

### Estimator
- **Model:** `LogisticRegression(max_iter=1000, class_weight="balanced", solver="liblinear")`

## Why logistic regression was selected here
Although the problem is framed as ranking, the implementation uses logistic regression as a **binary probability model** for patient-program match likelihood.

This choice was made because:
- it is stable and reproducible on tabular data,
- it scales well to large one-hot encoded sparse matrices,
- it naturally produces a score that can be used for ranking,
- it is easy to serialize and deploy,
- class weighting helps with the extreme imbalance caused by one positive pair and many negative pairs per patient,
- it offers a transparent baseline before moving to more complex rankers.

## Group-aware train/test split
The script uses:
- `GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=42)`

The grouping key is the patient ID. This prevents some patient-program pairs for the same patient from leaking into both train and test sets.

That design is important because the pair dataset contains multiple rows per patient.

## Commands
### Train
```bash
python build_facility_ranker.py train \
  --clinical "sparksync_clinical_data_with_outcomes (1).csv" \
  --programs "programs_ml_dataset clean.xlsx" \
  --model-out facility_ranker.joblib \
  --metrics-out facility_ranker_metrics.json \
  --predictions-out facility_ranker_holdout.csv \
  --template-out new_patient_template.csv
```

### Create blank scoring template
```bash
python build_facility_ranker.py template \
  --clinical "sparksync_clinical_data_with_outcomes (1).csv" \
  --out new_patient_template.csv
```

### Score new patients
```bash
python build_facility_ranker.py predict \
  --model-in facility_ranker.joblib \
  --new-patients new_patient_template.csv \
  --out scored_recommendations.csv \
  --top-k 5
```

## Model bundle contents
The saved `.joblib` bundle contains:
- trained pipeline
- program catalog dataframe
- feature column list
- numeric column list
- categorical column list
- expected patient column list
- metadata about training

## Outputs
### From `train`
- `.joblib` model bundle
- optional metrics JSON
- optional holdout ranking file
- optional scoring template

### From `predict`
A ranked output file with one row per recommendation, including:
- patient identifiers if available
- patient demographic/clinical columns if selected in output
- `program_name`
- `score`
- `recommendation_rank`
- selected program descriptors when available

## Metrics reported
- `top_1_accuracy`
- `top_3_accuracy`
- `top_5_accuracy`
- `top_1_exact_match`
- full classification report based on the top-ranked facility per patient

The top-k metrics are the most important for this script because the operational goal is recommendation support, not only exact single-label prediction.

## Handling unseen or rare facilities
Facilities that do not appear as positive outcomes in the clinical data have no direct positive examples in training. The model can still score them at inference time because it sees their program attributes, but those scores are extrapolations rather than learned from confirmed outcomes.

## Technical limitations
1. Cross joining patients to all programs can grow the dataset quickly.
2. The current pairwise match logic is rule-based and can be expanded.
3. Logistic regression may miss nonlinear interactions.
4. No explicit probability calibration is applied.
5. New program scoring is possible, but confidence is limited when there are no historical positive examples.

## Best use case
Use this script when you want a **deployable recommendation engine** that ranks facilities for new patients using both patient and program information.

## Key functions
- `read_table()` — reads CSV/XLSX
- `clean_inputs()` — standardizes input values
- `build_pair_dataset()` — creates patient-program cross join
- `add_pair_features()` — creates alignment features
- `build_feature_lists()` — identifies model features
- `make_pipeline()` — builds the preprocessing + estimator pipeline
- `train_model()` — trains model and evaluates holdout ranking
- `score_new_patients()` — applies trained model to new patients
- `write_template()` — writes blank template for new scoring data
- `save_bundle()` / `load_bundle()` — persistence helpers

## Recommended next upgrades
- try LightGBM, CatBoost, or XGBoost for nonlinear ranking signal,
- calibrate probabilities,
- add SHAP or coefficient-based explanation exports,
- add geographic distance features,
- add facility capacity, insurance, wait-time, and cost realism constraints,
- replace heuristic match features with richer semantic mappings.
