# README — `build_facility_prediction_model.py`

## Purpose
This script trains a **multiclass facility classifier** that predicts a patient's observed treatment destination directly from patient-level clinical features. The target variable is `actual_disposition` from the clinical dataset.

This is the simpler baseline approach. It is useful for:
- establishing an initial benchmark,
- understanding which patient variables carry signal,
- measuring whether the destination can be learned as a direct class label,
- generating feature-level interpretation from a linear model.

## Data inputs
The script expects the following files in `/mnt/data`:
- `sparksync_clinical_data_with_outcomes (1).csv`
- `programs_ml_dataset clean.xlsx`

Only the clinical file is used for training the classifier. The programs file is used to compare the set of observed outcome facilities against the full program catalog.

## Target definition
- **Target column:** `actual_disposition`
- **Prediction type:** multiclass classification
- **Unit of prediction:** one patient row → one predicted facility label

## High-level pipeline
1. Load clinical and program data.
2. Identify facility names present in the clinical outcomes and compare them to the catalog.
3. Build feature matrix `X` from clinical variables.
4. Remove `mrn` and the target from the features.
5. Optionally exclude `last_elected_program` to reduce leakage risk.
6. Drop columns that are completely empty.
7. Treat `diagnosis_*` fields as categorical values.
8. Split the data into train and test sets using a stratified holdout split.
9. Preprocess features with:
   - median imputation + scaling for numeric columns,
   - most-frequent imputation + one-hot encoding for categorical columns.
10. Train a logistic regression classifier with class balancing.
11. Evaluate holdout performance and export feature importance summaries.

## Model architecture
### Preprocessing
- **Numeric:** `SimpleImputer(strategy="median")` → `StandardScaler()`
- **Categorical:** `SimpleImputer(strategy="most_frequent")` → `OneHotEncoder(handle_unknown="ignore")`

### Estimator
- **Model:** `LogisticRegression(max_iter=2000, class_weight='balanced')`

## Why this model was selected
This model was chosen as the first baseline because:
- it handles mixed numeric and categorical tabular data well when paired with one-hot encoding,
- it is fast to train and easy to reproduce,
- it produces directly interpretable coefficients,
- class weighting helps with facility imbalance,
- it provides calibrated-enough class probabilities for top-k ranking analysis.

This model is intentionally simple. It is appropriate when the goal is to establish a benchmark before moving to more complex approaches.

## Leakage considerations
The script excludes `last_elected_program` by default in `prepare_features(..., include_last_elected_program=False)`. That column may reflect a near-final choice and can artificially inflate performance if the intention is to predict facility preference from upstream clinical factors alone.

## Outputs
The script writes the following files to `/mnt/data`:
- `facility_model_metrics.csv` — overall metrics
- `facility_model_class_metrics.csv` — per-facility precision/recall/F1/support
- `facility_model_predictions.csv` — top-3 predictions for each holdout row
- `facility_model_top_features.csv` — strongest coefficients by predicted facility
- `facility_model_summary.txt` — brief run summary

## Metrics reported
- Accuracy
- Macro F1
- Weighted F1
- Top-3 accuracy

These metrics are appropriate because the classes are imbalanced and a shortlist of candidate facilities is often more useful than only the exact top-1 label.

## Limitations
1. Facilities absent from `actual_disposition` cannot be learned as classes.
2. The model does not use program-level metadata when making predictions.
3. One-vs-rest linear decision boundaries may underfit nonlinear relationships.
4. The output is a direct class label, not a full patient-to-program scoring framework.

## Best use case
Use this script when you want a **benchmark classifier** and interpretable coefficients to understand the direct predictive signal in the clinical data.

## Example execution
```bash
python build_facility_prediction_model.py
```

## Key functions
- `load_data()` — loads clinical and catalog files
- `prepare_features()` — creates `X`, `y`, and column groups
- `build_pipeline()` — constructs preprocessing + classifier pipeline
- `extract_top_features()` — exports strongest linear coefficients per class
- `main()` — orchestrates train/test split, training, evaluation, and file export

## Recommended extensions
- compare against tree-based models such as LightGBM or XGBoost,
- use repeated cross-validation instead of one holdout split,
- add probability calibration,
- move from direct multiclass prediction to a ranking model that combines patient and program attributes.
